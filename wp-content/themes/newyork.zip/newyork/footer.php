              <footer class="page-footer">
                  <footer role="contentinfo">
                     <div class="site-footer">
                        
                        <div class="site-footer__sub">
                           <div class="site-footer__sub__inner">
                              <div class="site-footer__legal">
                                 <span class="site-footer__legal__copyright-message">© Cult Of Web</span>
                                 <div class="site-footer__legal__privacy-links">
                                    <ul class="footer-level-nav">
                                       <li class="footer-level-nav__item"><a class="footer-level-nav__item__link" href="http://cultofweb.com/blog/about/">About Us</a></li>
                                       <li class="footer-level-nav__item"><a class="footer-level-nav__item__link" href="http://cultofweb.com/blog/privacy_policy/">Privacy Policy</a></li>
                                       <li class="footer-level-nav__item"><a class="footer-level-nav__item__link" href="http://cultofweb.com/blog/sitemap/">Sitemap</a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="site-footer__language"><span></span></div>
                              <div class="site-footer__socials">
                                 <ul class="footer-level-nav">
                                    <li class="footer-level-nav__item"><a href="https://www.facebook.com/cultofweb" class="icon-button icon-button--simple"><span class="icon icon--facebook-2"></span></a></li>
                                    <li class="footer-level-nav__item"><a href="https://www.twitter.com/cult_web" class="icon-button icon-button--simple"><span class="icon icon--twitter-1"></span></a></li>                                   
                                    
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>
                  </footer>
               </footer>
            </div>
            <!-- .max--desktop -->
         </div>
         <!-- .site-wrapper -->
         
<!-- All Scripts goes below -->
<script type='text/javascript' src='https://cultofweb.com/blog/wp-content/themes/newyork/assets/js/jquery.js'></script>
<script type='text/javascript' src='https://cultofweb.com/blog/wp-content/themes/newyork/assets/js/script.min.js'></script>
<?php wp_footer(); ?>
</body>
</html>
